<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>LPM</title>
</head>
<body>
[APP_LINK]
</body>
</html>