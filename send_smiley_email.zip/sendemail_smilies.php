<?php
require_once("swiftmailer/lib/swift_required.php");

$from = array('info@share-a-success.com' =>'ShareASuccess');

// Create the Transport
$transport = Swift_SmtpTransport::newInstance('smtp.mandrillapp.com', 587);
$transport->setUsername('Frozentraffic');
$transport->setPassword('-R5U06-4VHRJyTPUHIeNiQ');


// Create the Mailer using your created Transport
$mailer = Swift_Mailer::newInstance($transport);

$message_template = file_get_contents("template-email.php");  
$app_link = "<p style='font-size:300%;'><a href='https://www.google.com'>😀</a>
<a href='https://www.bing.com'>🙁</a>
<a href='https://www.apple.com'>😠</a></p>";

$message = str_ireplace('[APP_LINK]',$app_link, $message_template);
// Create a message
$message = (new Swift_Message('Question'))
  ->setFrom($from)
  ->setTo(['chenghe8811@outlook.com'=>"suju8811"])
  ->setBody($message,'text/html')
  ;

// Send the message
$result = $mailer->send($message);
echo $result;
?>